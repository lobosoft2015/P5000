package P5000;


public class Plaqueta {
	

}
